<?php
/**
 * The template for displaying search forms in wpjobboard_theme
 *
 * @package wpjobboard_theme
 */
?>
<?php echo $theme->before_widget ?>
<?php if ($title) echo $theme->before_title . $title . $theme->after_title ?>

<div>
	<div id="adv">

	</div>

</div>

<?php echo $theme->after_widget ?>
